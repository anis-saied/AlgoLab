def clean( s ):
    news = ""
    s = s.lower()
    for c in s:
        if c >= "a" and c <= "z":
            news += c
        else:
            news += " "
    return news

fp = open( "pc_woodchuck.txt" )
text = fp.read()
fp.close()

dict = {}
for word in clean( text ).split():
    dict[word] = dict.get( word, 0 ) + 1
    
keylist = list( dict.keys() )
keylist.sort()
for key in keylist:
    print( "{}: {}".format( key, dict[key] ) )