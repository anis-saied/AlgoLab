def clean( s ):
    news = ""
    s = s.lower()
    for c in s:
        if c >= "a" and c <= "z":
            news += c
        else:
            news += " "
    return news

dict = {}
fp = open( "pc_woodchuck.txt" )
while True:
    line = fp.readline()
    if line == "":
        break
    for word in clean( line ).split():
        dict[word] = dict.get( word, 0 ) + 1
fp.close()
    
keylist = list( dict.keys() )
keylist.sort()
for key in keylist:
    print( "{}: {}".format( key, dict[key] ) )