for num in range( 1, 101 ):
    if num%2 == 0:
        continue
    if num%3 == 0:
        continue
    if num%10 == 7:
        continue
    if num%10 == 9:
        continue
    if num > 9:
        if num%10 == int( num / 10 ):
            continue
    print( num )