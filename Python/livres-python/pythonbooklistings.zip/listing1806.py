FILENAME = "pc_binarytest.tmp"
fp = open( FILENAME )
while True:
    buffer = fp.readline()
    if buffer == "":
        break
    print( buffer )
fp.close()